### R code from vignette source 'tutorial.Rnw'

###################################################
### code chunk number 1: tutorial.Rnw:50-53
###################################################
library(gdxrrw)
# igdx('/path/to/GAMS/sysdir') if not taken from environment
igdx()


###################################################
### code chunk number 2: tutorial.Rnw:59-60
###################################################
gams('transport')


###################################################
### code chunk number 3: tutorial.Rnw:66-71
###################################################
I <- rgdx.set('outputs.gdx','I')
J <- rgdx.set('outputs.gdx','J')
a <- rgdx.param('outputs.gdx','a')
b <- rgdx.param('outputs.gdx','b')
c <- rgdx.param('outputs.gdx','c')


###################################################
### code chunk number 4: tutorial.Rnw:76-84
###################################################
wgdx.lst('intest',list(I,J,a,b,c))
rc <- system('gdxdiff intest inputs')
if (0 == rc) print ("identical inputs") else print ("different inputs")
gams('transport.gms --INPUT intest.gdx --OUTPUT outtest.gdx')
zlst <- rgdx('outputs.gdx',list(name='z'))
z <- zlst$val
zlst <- rgdx('outtest.gdx',list(name='z'))
if (zlst$val == z) print ("identical objective") else print ("different objective")


###################################################
### code chunk number 5: tutorial.Rnw:88-95
###################################################
c2 <- c
c2[,'value'] <- c[,'value'] * 2
wgdx.lst('in2',list(I,J,a,b,c2))
gams('transport.gms --INPUT in2.gdx --OUTPUT out2.gdx')
zlst <- rgdx('out2.gdx',list(name='z'))
z2 <- zlst$val
print(paste('original=', z,'  double=',z2))


###################################################
### code chunk number 6: tutorial.Rnw:105-126
###################################################
data(state)
src <- c('California','Washington','New York','Maryland')
dst <- setdiff(state.name,src)
supTotal <- 1001
demTotal <- 1000
srcPop <- state.x77[src,'Population']
srcPopTot <- sum(srcPop)
dstPop <- state.x77[dst,'Population']
dstPopTot <- sum(dstPop)
sup <- (srcPop / srcPopTot) * supTotal
dem <- (dstPop / dstPopTot) * demTotal
x <- state.center$x
names(x) <- state.name
y <- state.center$x
names(y) <- state.name
cost <- matrix(0,nrow=length(src),ncol=length(dst),dimnames=list(src,dst))
for (s in src) {
  for (d in dst) {
    cost[s,d] <- sqrt((x[s]-x[d])^2 + (y[s]-y[d])^2)
  }
}


###################################################
### code chunk number 7: tutorial.Rnw:133-143
###################################################
ilst <- list(name='I',uels=list(src),ts='supply states')
jlst <- list(name='J',uels=list(dst),ts='demand states')
suplst <- list(name='a',val=as.array(sup),uels=list(src),
               dim=1,form='full',type='parameter',ts='supply limits')
demlst <- list(name='b',val=as.array(dem),uels=list(dst),
               dim=1,form='full',type='parameter',ts='demand quantities')
clst <- list(name='c',val=cost,uels=list(src,dst),
             dim=2,form='full',type='parameter',
             ts='transportation costs')
wgdx.lst('inStates',list(ilst,jlst,suplst,demlst,clst))


###################################################
### code chunk number 8: tutorial.Rnw:148-151
###################################################
gams('transport.gms --INPUT inStates.gdx --OUTPUT outStates.gdx')
ms <- rgdx.scalar('outStates.gdx','modelStat')
print(paste('Model status:',ms))


###################################################
### code chunk number 9: tutorial.Rnw:159-161
###################################################
rc <- gams('transport --INPUT notHere')
if (0 == rc) print ("normal gams return") else print ("abnormal gams return")


###################################################
### code chunk number 10: tutorial.Rnw:169-175
###################################################
a2 <- a
a2[a2$i == 'seattle','value'] <- a2[a2$i == 'seattle','value'] - 100
wgdx.lst('inInf',list(I,J,a2,b,c))
gams('transport.gms --INPUT inInf.gdx --OUTPUT outInf.gdx')
ms <- rgdx.scalar('outInf.gdx','modelStat')
if (4 == ms) print ("The model is infeasible")


