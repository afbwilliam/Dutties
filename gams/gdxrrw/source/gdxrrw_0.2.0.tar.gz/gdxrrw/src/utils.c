/* utils.c
 * utility functions for gdxrrw package
 * $Id: utils.c 35591 2012-10-02 13:45:13Z sdirkse $
 */

#include <R.h>
#include <Rinternals.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <math.h>
#include <assert.h>

#include "gdxcc.h"
#include "gclgms.h"
#include "globals.h"

/* just to shut up some warnings on Linux */
typedef int (*compareFunc_t) (const void *, const void *);

/* checkForDuplicates
 * checks the input array of strings for duplicates,
 * throwing an error is there are any
 */
static void
checkForDuplicates (SEXP strExp)
{
  int k;
  shortStringBuf_t *elements;
  int nRec;

  /* store all the strings in temporary storage */
  nRec = length(strExp);

  elements = malloc(nRec * sizeof(*elements));
  for (k = 0; k < nRec; k++) {
    strcpy(elements[k], CHAR(STRING_ELT(strExp, k)));
  }

  /* sort the strings */
  qsort (elements, nRec, sizeof(*elements), (compareFunc_t)strcmp);

  /* check for duplicates */
  for (k = 0;  k < nRec - 1;  k++) {
    if (0 == strcmp(elements[k], elements[k+1])) {
      Rprintf ("Input UEL filter has duplicate entry of '%s'\n",
               elements[k]);
      error ("UEL filters must not contain duplicates.");
    }
  }
  free (elements);
} /* checkForDuplicates */

/* ------------------ start of globally available functions --------------- */

/* CHAR2ShortStr
 * copy the input C-style string to a shortString buffer
 * return the output buffer, nor NULL if there is no input
 */
char *
CHAR2ShortStr (const char *from, shortStringBuf_t to)
{
  size_t n;

  if (NULL == from)
    return NULL;
  n = strlen(from);
  if (n >= sizeof(shortStringBuf_t)) {
    n = sizeof(shortStringBuf_t);
    strncpy(to, from, n);
    to[n-1] = '\0';
  }
  else
    strcpy(to, from);
  return to;
} /* CHAR2ShortStr */

/* checkFileExtension: checks the file extension of the gdx file.
 * If fileName does not have '.gdx' then we add it here
*/
void
checkFileExtension (shortStringBuf_t fileName)
{
  char *fileExt;

  fileExt = strrchr (fileName, '.');
  if (NULL == fileExt) {
    if (strlen(fileName) < sizeof(shortStringBuf_t)-4) {
      fileName = strcat(fileName, ".gdx");
    }
    else {
      error ("Input file name '%s' is too long\n", fileName);
    }
  }
  else if (0 != strcasecmp(".gdx", fileExt)) {
    error ("Input file extension '%s' is not valid: input must be a GDX file\n",
           fileExt);
  }
  return;
} /* checkFileExtension */

/* checkStringLength
 * raise an exception if the input str is too long to be a short-string
 */
void
checkStringLength (const char *str)
{
  int i;

  i = (int) strlen (str);
  if (0 == i) {
    error ("Cannot access empty field. Please try again");
  }
  else if (i >= sizeof(shortStringBuf_t)) {
    error("The data entered is too long: len=%d exceeds limit=%d.",
          i, (int)sizeof(shortStringBuf_t)-1);
  }
} /* checkStringLength */

/* compressData: compress the $vals data (in sparse form)
 * and also the associated domains.
 *     in: symDim - symbol dimension
 *     in: mRows - nonzeros in symbol / rows in $vals
 *     in: uni, nUni - universe of uels and its size/count
 *     in: xpFilter_t filterList[]
 * in/out: spVals - $vals to output
 *    out: uelList - $uels to output
*/
void
compressData (int symDim, int mRows, SEXP uni, int nUni, xpFilter_t filterList[],
              SEXP spVals, SEXP uelList)
{
  int n;                  /* initial cardinality for this index pos */
  int nn;                 /* compressed cardinality */
  int nMax;
  int iDim, i, k, stop, nTmp;
  int *mask;
  double *v;                    /* index values in spVals */
  SEXP uelVec;                  /* elements of uelList */

  n = 0;                        /* shut up warnings */
  nMax = 0;
  for (iDim = 0;  iDim < symDim;  iDim++) {
    xpFilter_t *xpf = filterList + iDim;
    switch (xpf->fType) {
    case unset:
      error ("internal error: xpFilter type unset");
      break;
    case identity:
      /* assume index values in this dimension are in [1..nUni] */
      n = nUni;
      break;
    case integer:
      /* assume index values in this dimension are in [1..xpf->n] */
      n = xpf->n;
      break;
    default:
      error ("internal error: unknown hpFilter type");
    } /* end switch */
    if (n > nMax)
      nMax = n;
  } /* loop over index positions */

  mask = malloc(nMax*sizeof(*mask));
  v =  REAL(spVals);
  for (iDim = 0;  iDim < symDim;  iDim++) {
    nn = 0;
    xpFilter_t *xpf = filterList + iDim;
    switch (xpf->fType) {
    case unset:
      error ("internal error: xpFilter type unset");
      break;
    case identity:
      n = nUni;
      /* record and count used index values */
      /* (void) memset (mask, 0, nMax*sizeof(*mask)); */
      (void) memset (mask, 0, n*sizeof(*mask));
      for (k = mRows*iDim, stop = mRows*(iDim+1);  k < stop;  k++) {
        i = (int)v[k];          /* one-based */
        if ((i <= 0) || (i > n))
          error ("bogus index i found in compressData: iDim=%d n=%d i=%d",
                 iDim, n, i);
        i--;
        if (mask[i] == 0) {
          mask[i] = 1;
          nn++;
        }
      } /* loop over index values in this position */
      PROTECT(uelVec = allocVector(STRSXP, nn));
      SET_VECTOR_ELT(uelList, iDim, uelVec);
      UNPROTECT(1);
      /* loop over found index values in mask, computing new index values */
      for (nTmp = 0, i = 0;  i < n;  i++) {
        if (mask[i]) {
          SET_STRING_ELT(uelVec, nTmp, STRING_ELT(uni, i));
          nTmp++;
          mask[i] = nTmp;
        }
      }
      /*  update index values to compressed ordering */
      for (k = mRows*iDim, stop = mRows*(iDim+1);  k < stop;  k++) {
        i = (int)v[k] - 1;
        v[k] = mask[i];
      } /* loop over index values in this position */
      break;
    case integer:
      n = xpf->n;
      /* record and count used index values */
      /* (void) memset (mask, 0, nMax*sizeof(*mask)); */
      (void) memset (mask, 0, n*sizeof(*mask));
      for (k = mRows*iDim, stop = mRows*(iDim+1);  k < stop;  k++) {
        i = (int)v[k];          /* one-based */
        if ((i <= 0) || (i > n))
          error ("bogus index i found in compressData: iDim=%d n=%d i=%d",
                 iDim, n, i);
        i--;
        if (mask[i] == 0) {
          mask[i] = 1;
          nn++;
        }
      } /* loop over index values in this position */
      PROTECT(uelVec = allocVector(STRSXP, nn));
      SET_VECTOR_ELT(uelList, iDim, uelVec);
      UNPROTECT(1);
      /* loop over found index values in mask,
       * computing new index values and new output uels */
      for (nTmp = 0, i = 0;  i < n;  i++) {
        if (mask[i]) {
          SET_STRING_ELT(uelVec, nTmp, STRING_ELT(uni, xpf->idx[i]-1));
          nTmp++;
          mask[i] = nTmp;
        }
      }
      /*  update index values to compressed ordering */
      for (k = mRows*iDim, stop = mRows*(iDim+1);  k < stop;  k++) {
        i = (int)v[k] - 1;
        v[k] = mask[i];
      } /* loop over index values in this position */


      break;
    default:
      error ("internal error: unknown hpFilter type");
    } /* end switch */
  } /* loop over index positions */

  free(mask);
  return;
} /* compressData */

/* createElementMatrix: what does this do?
 * create text element Matrix from sparse data and element vector
 */
void
createElementMatrix (SEXP compVal, SEXP textElement, SEXP compTe,
                     SEXP compUels, int symDim, int nRec)
{
  int i, j, iRec, index, totNumber;
  double *p;

  /* Step 1: loop over full matrix and set every value as empty string */
  for (j = 0; j < length(compTe); j++) {
    SET_STRING_ELT(compTe, j, mkChar(""));
  }

  /* Step 2: loop over each row of sparse matrix and populate full matrix */
  p = REAL(compVal);

  for (iRec = 0; iRec < nRec; iRec++) {
    index = 0;
    totNumber = 1;
    for (i = 0;  i < symDim;  i++) {
      index = index + ((int)p[iRec + nRec*i] - 1)*totNumber;
      totNumber = (totNumber)*length(VECTOR_ELT(compUels, i));
    }
    SET_STRING_ELT(compTe, index, duplicate(STRING_ELT(textElement, iRec)) );
  }

  return;
} /* createElementMatrix */

/* mkHPFilter: construct an integer filter from the user-supplied string uels
 * ufilter: user-supplied filter - $uels[k]
 * hpf: high-performance filter for internal use
 */
void
mkHPFilter (SEXP uFilter, hpFilter_t *hpf)
{
  int k, n;
  int *idx;
  const char *uelString;
  int isOrdered = 1;
  int dummy, uelInt, lastUelInt;
  int allFound = 1;    /* all strings from the filter found in GDX? */
  int found;

  hpf->fType = integer;
  hpf->n = n = length(uFilter);
  /* Rprintf ("  mkHPFilter: n = %d\n", n); */
  hpf->prevPos = 0;
  hpf->idx = idx =  malloc(n * sizeof(*idx));
  if (NULL == idx)
    error ("memory exhaustion error: could not allocate index for hpFilter");
  for (lastUelInt = 0, k = 0;  k < n;  k++) {
    uelString = CHAR(STRING_ELT(uFilter, k));
    found = gdxUMFindUEL (gdxHandle, uelString, &uelInt, &dummy);
    /* Rprintf ("       k = %2d:  %s  %d  %d\n", k, uelString, uelInt, dummy); */
    if (! found) {                /* not found */
      allFound = 0;
      isOrdered = 0;            /* for now insist all are found to be ordered */
    }
    else if (isOrdered) {
      if (uelInt > lastUelInt)
        lastUelInt = uelInt;
      else
        isOrdered = 0;
    }
    idx[k] = uelInt;
  }
  hpf->isOrdered = isOrdered;
  if (! isOrdered) {
    checkForDuplicates (uFilter);
  }
  /* Rprintf ("  mkHPFilter: isOrdered = %d  allFound = %d\n", isOrdered, allFound); */
  return;
} /* mkHPFilter */

/* mkXPFilters: construct XPfilter from what?
 * symIdx: of symbol to construct filter for
 * xpf: high-performance filter for internal use
 */
void
mkXPFilter (int symIdx, Rboolean useDomInfo, xpFilter_t filterList[], SEXP outDomains)
{
  int rc, iRec, nRecs, changeIdx;
  int kSym, kDim, kType;        /* for loop over index sets */
  int iDim, symDim, symType, symNNZ, symUser;
  int *idx;
  shortStringBuf_t symName, kName, symText;
  gdxStrIndex_t domNames;
  gdxStrIndexPtrs_t domPtrs;
  gdxUelIndex_t symDoms;
  gdxUelIndex_t uels;
  gdxValues_t values;
  xpFilter_t *xpf;

  GDXSTRINDEXPTRS_INIT (domNames, domPtrs);
  /* gdxSymbolGetDomainX is/was buggy and might not write the domain names
   * set to '*' to work around that */
  for (iDim = 0;  iDim < GLOBAL_MAX_INDEX_DIM;  iDim++)
    strcpy (domPtrs[iDim], "*");

  rc = gdxSymbolInfo (gdxHandle, symIdx, symName, &symDim, &symType);
  if (! rc)
    error ("bad return from gdxSymbolInfo in mkXPFilter");
  if (symDim <= 0)
    return;                     /* skip scalars */
  switch (symType) {
  case GMS_DT_PAR:
  case GMS_DT_SET:
  case GMS_DT_VAR:
  case GMS_DT_EQU:
    if (useDomInfo)
      rc = gdxSymbolGetDomainX (gdxHandle, symIdx, domPtrs);
    else
      rc = 1;                   /* no domain info available */
    switch (rc) {
    case 1:                   /* NA: no domain info */
      for (iDim = 0;  iDim < symDim;  iDim++) {
        xpf = filterList + iDim;
        xpf->domType = none;
        xpf->fType = identity;
      } /* end loop over dims */
      if (R_NilValue != outDomains) {
        for (iDim = 0;  iDim < symDim;  iDim++) {
          SET_STRING_ELT(outDomains, iDim, mkChar("*"));
        }
      }
      break;
    case 2:                   /* relaxed domain info */
      for (iDim = 0;  iDim < symDim;  iDim++) {
        xpf = filterList + iDim;
        SET_STRING_ELT(outDomains, iDim, mkChar(domPtrs[iDim]));
        if (0 == strcmp(domPtrs[iDim],"*")) { /* not available: use the universe */
          xpf->domType = none;
          xpf->fType = identity;
          continue;
        }
        rc = gdxFindSymbol (gdxHandle, domPtrs[iDim], &kSym);
        if (! rc) {             /* not available: use the universe */
          xpf->domType = none;
          xpf->fType = identity;
          continue;
        }
        /* now we have the nice case: set symbol is in GDX */
        rc = gdxSymbolInfo (gdxHandle, kSym, kName, &kDim, &kType);
        if (! rc)
          error ("bad return from gdxSymbolInfo in mkXPFilter");
        if (0 != strcmp(domPtrs[iDim],kName))
          error ("bad domain lookup: %s <> %s", domPtrs[iDim], kName);
        if (GMS_DT_ALIAS == kType) {
          gdxSymbolInfoX (gdxHandle, kSym, &symNNZ, &symUser, symText);
          kSym = symUser;
          rc = gdxSymbolInfo (gdxHandle, kSym, kName, &kDim, &kType);
          if (! rc)
            error ("bad return from gdxSymbolInfo in mkXPFilter");
        }
        if ((1 != kDim) || (GMS_DT_SET != kType))
          error ("non-domain-set data from gdxSymbolInfo in mkXPFilter");
        xpf->domType = relaxed;
        xpf->fType = integer;
        xpf->prevPos = 0;
        gdxDataReadRawStart (gdxHandle, kSym, &nRecs);
        xpf->n = nRecs;
        xpf->idx = idx =  malloc(nRecs * sizeof(*idx));
        for (iRec = 0;  iRec < nRecs;  iRec++) {
          gdxDataReadRaw (gdxHandle, uels, values, &changeIdx);
          idx[iRec] = uels[0];
        } /* loop over GDX records */
        if (!gdxDataReadDone (gdxHandle)) {
          error ("Could not gdxDataReadDone");
        }
      } /* end loop over dims */
      break;
    case 3:                   /* full domain info */
      rc = gdxSymbolGetDomain (gdxHandle, symIdx, symDoms);
      if (! rc)
        error ("error calling gdxSymbolGetDomain");
      for (iDim = 0;  iDim < symDim;  iDim++) {
        SET_STRING_ELT(outDomains, iDim, mkChar(domPtrs[iDim]));
        kSym = symDoms[iDim];
        rc = gdxSymbolInfo (gdxHandle, kSym, kName, &kDim, &kType);
        if (! rc)
          error ("bad return from gdxSymbolInfo in mkXPFilter");
        if (GMS_DT_ALIAS == kType) {
          gdxSymbolInfoX (gdxHandle, kSym, &symNNZ, &symUser, symText);
          kSym = symUser;
          rc = gdxSymbolInfo (gdxHandle, kSym, kName, &kDim, &kType);
          if (! rc)
            error ("bad return from gdxSymbolInfo in mkXPFilter");
        }
        if ((1 != kDim) || (GMS_DT_SET != kType))
          error ("non-domain-set data from gdxSymbolInfo in mkXPFilter");
        xpf = filterList + iDim;
        xpf->domType = regular;
        xpf->fType = integer;
        xpf->prevPos = 0;
        gdxDataReadRawStart (gdxHandle, kSym, &nRecs);
        xpf->n = nRecs;
        xpf->idx = idx =  malloc(nRecs * sizeof(*idx));
        for (iRec = 0;  iRec < nRecs;  iRec++) {
          gdxDataReadRaw (gdxHandle, uels, values, &changeIdx);
          idx[iRec] = uels[0];
        } /* loop over GDX records */
        if (!gdxDataReadDone (gdxHandle)) {
          error ("Could not gdxDataReadDone");
        }
      } /* loop over domain sets */
      break;
    case 0:                   /* bad input */
    default:
      error ("unexpected return (%d) from gdxSymbolGetDomainX", rc);
    } /* switch */
    break;
  default:
    error ("mkXPFilter: symbol %s has type %d (%s): unimplemented\n",
           symName, symType, gmsGdxTypeText[symType]);
  } /* switch (symType) */

  return;
} /* mkXPFilter */

/* prepHPFilter: prep/check a high-performance filter prior to use
 * This is not initializing data, just initializing prevPos
 * and perhaps some debugging-type checks on consistency
 */
void
prepHPFilter (int symDim, hpFilter_t filterList[])
{
  int iDim;
  hpFilter_t *hpf;

  if (NULL == filterList)
    error ("internal error: NULL hpFilter");
  for (iDim = 0;  iDim < symDim;  iDim++) {
    hpf = filterList + iDim;
    switch (hpf->fType) {
    case unset:
      error ("internal error: hpFilter type unset");
      break;
    case identity:
      error ("internal error: just sanity checking");
      break;
    case integer:
      if (hpf->n <= 0)
        error ("internal error: integer hpFilter must be nonempty"); /* really? */
      hpf->prevPos = 0;
      break;
    default:
      error ("internal error: unknown hpFilter type");
    }
  } /* loop over symbol dimensions */
} /* prepHPFilter */

/* findInHPFilter: search for inUels in filterList,
 * storing 1 + the index where found in outIdx[k], i.e. index in [1,filterList[k].n]
 * as a side effect, updates previous search info in filterList
 * return:
 *   1     if found,
 *   0     otherwise
 */
int
findInHPFilter (int symDim, const int inUels[], hpFilter_t filterList[],
                int outIdx[])
{
  int iDim, k, targetUel, found, isOrdered;
  const int *idx;
  hpFilter_t *hpf;

  if (NULL == filterList)
    error ("internal error: NULL hpFilter");
  for (iDim = 0;  iDim < symDim;  iDim++) {
    hpf = filterList + iDim;
    switch (hpf->fType) {
    case unset:
      error ("internal error: hpFilter type unset");
      break;
    case identity:
      outIdx[iDim] = inUels[iDim];
      break;
    case integer:
      idx = hpf->idx;
      isOrdered = hpf->isOrdered;
      targetUel = inUels[iDim];
      found = 0;
      if (isOrdered) {
        /* search starting with previous found position */
        for (k = hpf->prevPos;  k < hpf->n;  k++) {
          if (idx[k] == targetUel) {
            hpf->prevPos = k;
            outIdx[iDim] = k + 1;
            found = 1;
            break;
          }
          else if (idx[k] > targetUel)
            break;
        } /* loop over filter elements */
        if (! found) {          /* search from the beginning */
          for (k = 0;  k < hpf->n;  k++) {
            if (idx[k] == targetUel) {
              hpf->prevPos = k;
              outIdx[iDim] = k + 1;
              found = 1;
              break;
            }
            else if (idx[k] > targetUel)
              break;
          } /* loop over filter elements */
        }
      } /* if (isOrdered) */
      else {
        for (k = 0;  k < hpf->n;  k++) {
          if (idx[k] == targetUel) {
            hpf->prevPos = k;
            outIdx[iDim] = k + 1;
            found = 1;
            break;
          }
        } /* loop over filter elements */
      } /* if (isOrdered) .. else .. */
      if (! found)
        return 0;
      break;
    default:
      error ("internal error: unknown hpFilter type");
    }
  } /* loop over symbol dimensions */
  return 1;                     /* found */
} /* findInHPFilter */

/* findInXPFilter: search for inUels in filterList,
 * storing 1 + the index where found in outIdx[k], i.e. index in [1,filterList[k].n]
 * as a side effect, updates previous search info in filterList
 * return:
 *   0     if found,
 *   iDim  otherwise, where iDim in [1..symDim] is the leftmost bad index pos
 * similar to findInHPFilter, but XPFilter assumes
 * the filters and the inputs are ordered
 */
int
findInXPFilter (int symDim, const int inUels[], xpFilter_t filterList[],
                int outIdx[])
{
  int iDim, k, targetUel, stop;
  const int *idx;
  xpFilter_t *xpf;
  int reset = 0;                /* the left-most first moving index
                                 * resets all searches to the right */

  if (NULL == filterList)
    error ("internal error: NULL xpFilter");
  for (iDim = 0;  iDim < symDim;  iDim++) {
    xpf = filterList + iDim;
    switch (xpf->fType) {
    case unset:
      error ("internal error: xpFilter type unset");
      break;
    case identity:
      outIdx[iDim] = inUels[iDim];
      if (reset) {
        xpf->prevPos = inUels[iDim];
      }
      else {
        if      (xpf->prevPos < inUels[iDim]) {
          /* advanced in this index position */
          reset = 1;
          xpf->prevPos = inUels[iDim];
        }
        else if (xpf->prevPos == inUels[iDim])
          ;                     /* no change */
        else {
          /* moving back in this index position */
          return iDim + 1;
        }
      }
      break;
    case integer:
      idx = xpf->idx;
      targetUel = inUels[iDim];
      if (! reset) {
        /* optimize for the easy & common case: a repeat */
        if (idx[xpf->prevPos] == targetUel) {
          outIdx[iDim] = xpf->prevPos + 1;
          break;                /* from switch */
        }
        reset = 1;
        /* search starting one past the previous found position */
        for (k = xpf->prevPos + 1, stop = xpf->n;  k < stop;  k++) {
          if (idx[k] == targetUel) {
            xpf->prevPos = k;
            outIdx[iDim] = k + 1;
            break;              /* from for loop */
          }
          else if (idx[k] > targetUel) {
            return iDim + 1;
          }
        } /* loop over filter elements */
        if (k < stop)
          break;                /* from switch stmt */
        return iDim + 1;        /* not found??  bad! */
      }
      else {
        /* search was reset, must start from the beginning */
        ;
        for (k = 0, stop = xpf->n;  k < stop;  k++) {
          if (idx[k] == targetUel) {
            xpf->prevPos = k;
            outIdx[iDim] = k + 1;
            break;              /* from for loop */
          }
          else if (idx[k] > targetUel)
            return iDim + 1;
        } /* loop over filter elements */
        if (k < stop)
          break;                /* from switch stmt */
        return iDim + 1;        /* not found??  bad! */
      }
      break;
    default:
      error ("internal error: unknown hpFilter type");
    }
  } /* loop over symbol dimensions */
  return 0;                     /* found */
} /* findInXPFilter */

/* xpFilterToUels
 * create output uels (i.e. $uels) for an xpFilter
 */

void
xpFilterToUels (int symDim, xpFilter_t filterList[], SEXP uni, SEXP uels)
{
  int UELUserMapping;
  int iDim, n, k, iUEL;
  shortStringBuf_t uelName;
  SEXP s;
  xpFilter_t *xpf;

  for (iDim = 0;  iDim < symDim;  iDim++) {
    xpf = filterList + iDim;
    switch (xpf->fType) {
    case identity:
      SET_VECTOR_ELT(uels, iDim, uni);
      break;
    case integer:
      n = xpf->n;
      PROTECT(s = allocVector(STRSXP, n));
      for (k = 0;  k < n;  k++) {
        iUEL = xpf->idx[k];
        if (!gdxUMUelGet (gdxHandle, iUEL, uelName, &UELUserMapping)) {
          error("xpFilterToUels: could not gdxUMUelGet");
        }
        SET_STRING_ELT(s, k, mkChar(uelName));
      } /* loop over filter elements */
      SET_VECTOR_ELT(uels, iDim, s);
      UNPROTECT(1);
      break;
    default:
      error ("internal error creating output uels");
    }
  } /* loop over indices */
  return;
} /* xpFilterToUels */

/* This method will read variable "gamso" from R workspace */
char *getGlobalString (const char *globName, shortStringBuf_t result)
{
  SEXP gamso, lstNames, tmp;
  char *res;
  int k, infields, found;

  *result = '\0';
  res = NULL;
  if (gamsoIsUnset)
    return res;

  gamso = findVar (install("gamso"), R_GlobalEnv);

  if (gamso == NULL || TYPEOF(gamso) != VECSXP) {
    gamsoIsUnset = 1;
    globalGams = 0;
    return res;
  }

  if (globalGams == 1) {
    lstNames = getAttrib (gamso, R_NamesSymbol);
    infields = length(gamso);
    /* Checking if field data is for "globName" */
    for (found = 0, k = 0;  k < infields;  k++) {
      if (strcmp(globName, CHAR(STRING_ELT(lstNames, k))) == 0) {
        found = 1;
        break;
      }
    }

    if (found) {
      tmp = VECTOR_ELT(gamso, k);
      if (TYPEOF(tmp) == STRSXP) {
        checkStringLength (CHAR(STRING_ELT(tmp, 0)));
        res = CHAR2ShortStr (CHAR(STRING_ELT(tmp, 0)), result);
      }
      else {
        warning("To change default behavior of %s, please enter it as string.\n", globName);
        Rprintf("You entered it as %d.\n", TYPEOF(tmp));
        return NULL;
      }
    }
  }
  return res;
} /* getGlobalString */

/* getNonZeroElements
 * return nonzero count for the specified field of a variable or equation
 */
int
getNonZeroElements (gdxHandle_t h, int symIdx, dField_t dField)
{
  int nRecs, changeIdx, i, cnt;
  gdxUelIndex_t uels;
  gdxValues_t values;

  gdxDataReadRawStart (h, symIdx, &nRecs);
  for (cnt = 0, i = 0;  i < nRecs;  i++) {
    gdxDataReadRaw (h, uels, values, &changeIdx);
    if (values[dField] != 0) {
      cnt++;
    }
  }
  return cnt;
} /* getNonZeroElements */

/* interpret the squeeze arg for rgdx as a logical/boolean */
Rboolean
getSqueezeArgRead (SEXP squeeze)
{
  const char *s;

  switch (TYPEOF(squeeze)) {
  case LGLSXP:
    return LOGICAL(squeeze)[0];
    break;
  case INTSXP:
    return INTEGER(squeeze)[0];
    break;
  case REALSXP:
    if (0.0 == REAL(squeeze)[0])
      return FALSE;
    else
      return TRUE;
    break;
  case STRSXP:
    s = CHAR(STRING_ELT(squeeze, 0));
    if ('\0' == s[1])
      switch (s[0]) {
      case 'T':
      case 't':
      case 'Y':
      case 'y':
      case '1':
        return TRUE;
      case 'F':
      case 'f':
      case 'N':
      case 'n':
      case '0':
        return FALSE;
      default:
        return NA_LOGICAL;
      }
    if (0 == strcmp("TRUE",s)) return TRUE;
    if (0 == strcmp("True",s)) return TRUE;
    if (0 == strcmp("true",s)) return TRUE;
    if (0 == strcmp("YES",s)) return TRUE;
    if (0 == strcmp("Yes",s)) return TRUE;
    if (0 == strcmp("yes",s)) return TRUE;

    if (0 == strcmp("FALSE",s)) return FALSE;
    if (0 == strcmp("False",s)) return FALSE;
    if (0 == strcmp("false",s)) return FALSE;
    if (0 == strcmp("NO",s)) return FALSE;
    if (0 == strcmp("No",s)) return FALSE;
    if (0 == strcmp("no",s)) return FALSE;

    return NA_LOGICAL;
    break;
  }
  return NA_LOGICAL;
} /* getSqueezeArgRead */

/* this method for global input "compress" */
int isCompress (void)
{
  SEXP gamso, tmp, lstName;
  Rboolean logical = NA_LOGICAL;
  char *str;
  int i, infields;
  int compress = 0;
  int found = 0;
  shortStringBuf_t fName;

  str = NULL;
  gamso = findVar( install("gamso"), R_GlobalEnv );

  if (gamso == NULL || TYPEOF(gamso) == NILSXP  ||  TYPEOF(gamso) == SYMSXP) {
    globalGams = 0;
    return 0;
  }

  /*   if (TYPEOF(gamso) != VECSXP  && globalGams)
       {
       warning("To change default behavior, please enter 'gamso' as list.\n" );
       Rprintf("You entered it as %d.\n", TYPEOF(gamso) );
       globalGams = 0;
       return 0;
       } */

  else if (TYPEOF(gamso) == VECSXP && globalGams == 1) {
    lstName = getAttrib(gamso, R_NamesSymbol);
    i=0;
    infields = length(gamso);
    /* Checking if field data is for "name" */
    for (i = 0; i < infields; i++) {
      if (strcasecmp("compress", CHAR(STRING_ELT(lstName, i))) == 0) {
        found = 1;
        break;
      }
    }

    if (found == 1 && globalGams) {
      tmp = VECTOR_ELT(gamso, i);
      if (TYPEOF(tmp) == STRSXP) {
        str = CHAR2ShortStr (CHAR(STRING_ELT(tmp, 0)), fName);
        if (NULL != str) {
          if (strcasecmp(fName,"true") == 0)
            compress = 1;
          else if (strcmp(fName,"false") == 0)
            compress = 0;
          else {
            /* else warning message */
            warning ("To change default behavior of 'compress', please enter it as 'true' or 'false'\n" );
            Rprintf ("You entered it as %s.\n", str);
          }
        }
      } /* TYPEOF=STRSXP */
      else if (TYPEOF(tmp) == LGLSXP) {
        logical = LOGICAL(tmp)[0];
        if (logical == TRUE)
          compress = 1;
        else
          compress = 0;
      }
      else {
        warning ("To change default behavior of 'compress', please enter it as either a string or a logical.\n");
        Rprintf ("You entered it with TYPEOF('compress') = %d.\n", TYPEOF(tmp));
        return 0;
      }
    }
  }
  return compress;
} /* isCompress */

/* loadGDX: load the GDX API, if not already loaded,
 * and raise an exception on failure
 */
void
loadGDX (void)
{
  shortStringBuf_t msg;
  int rc;

  if (gdxLibraryLoaded())
    return;                     /* all done already */
  rc = gdxGetReady (msg, sizeof(msg));
  if (0 == rc) {
    Rprintf ("Error loading the GDX API\n");
    Rprintf ("%s\n", msg);
    Rprintf ("Hint: try calling igdx() with the name of the GAMS system directory\n");
    Rprintf ("      before calling this routine.\n");
#if defined(_WIN32)
    Rprintf ("      You can also add the GAMS system directory to the PATH.\n");
#elif defined(__APPLE__)
    Rprintf ("      You can also add the GAMS system directory to the PATH\n");
    Rprintf ("      and to DYLD_LIBRARY_PATH.\n");
#else
    Rprintf ("      You can also add the GAMS system directory to the PATH\n");
    Rprintf ("      and to LD_LIBRARY_PATH.\n");
#endif
    error ("Error loading the GDX API: %s", msg);
  }
  return;
} /* loadGDX */

/* makeStrVec
 * converts the input vector of ints or reals into strings
 * both inExp and outExp are assumed to be allocated on input
 */
void
makeStrVec (SEXP outExp, SEXP inExp)
{
  int  len;
  char buf[256];
  double *doubleData;
  int *intData;
  int k;

  len = length(inExp);
  if (TYPEOF(inExp) == REALSXP) {
    doubleData = REAL(inExp);
    for (k = 0; k < len; k++) {
      sprintf(buf, "%g", doubleData[k]);
      SET_STRING_ELT(outExp, k, mkChar(buf));
    }
  }
  else if (TYPEOF(inExp) == INTSXP) {
    intData = INTEGER(inExp);
    for (k = 0; k < len; k++) {
      sprintf(buf, "%i", intData[k]);
      SET_STRING_ELT(outExp, k, mkChar(buf));
    }
  }
  else if (TYPEOF(inExp) == STRSXP) {
    for (k = 0; k < len; k++) {
      SET_STRING_ELT(outExp, k, duplicate(STRING_ELT(inExp, k)));
    }
  }

  checkForDuplicates (outExp);

  return;
} /* makeStrVec */

/* sparseToFull: from input data in sparse for, create output data in full form
 * spVal: input .val matrix in sparse form
 * uelLists: .uels for symbol
 * fullVal: output .val matrix in full form
 */
void
sparseToFull (SEXP spVal, SEXP fullVal, SEXP uelLists,
              int symType, int nRec, int symDim)
{
  int k, iRec;
  int card[GLOBAL_MAX_INDEX_DIM];
  double *p, *pFull;
  int index;
#if 1
  int ii;
#else
  int stride;
#endif

  /* step 1: loop over full matrix and set every value as 0 */
  pFull = REAL(fullVal);
#if 0
  for (k = 0;  k < length(fullVal);  k++) {
    pFull[k] = 0;
  }
#else
  (void) memset (pFull, 0, length(fullVal) * sizeof(*pFull));
#endif

  /* N.B.: R stores matrices column-wise, i.e. left index moving fastest */
  /* step 2: loop over each row/nonzero of sparse matrix to populate full matrix */
  p = REAL(spVal);
  for (k = 0;  k < symDim;  k++) {
    card[k] = length(VECTOR_ELT(uelLists, k)); /* number of elements in dim k */
  }

  for (iRec = 0;  iRec < nRec;  iRec++) {
#if 0
    index = 0;
    stride = 1;              /* something like Horner's method here */
    for (k = 0; k < symDim; k++) {
      index = index + (p[iRec + nRec*k] - 1)*stride;
      stride *= card[k];
    }
#else
    ii = iRec + nRec*(symDim-1);
    for (index = p[ii]-1, k = symDim-2;  k >= 0;  k--) {
      ii -= nRec;
      index = (index * card[k]) + p[ii] - 1;
    }
#endif
    if (symType != GMS_DT_SET) {
      pFull[index] = p[iRec + nRec*symDim];
    }
    else {
      pFull[index] = 1;
    }
  }
  return;
} /* sparseToFull */

